// resetAdminPassword.js
import dotenv from "dotenv";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import User from "./src/models/User.js";

dotenv.config(); // lee .env (MONGO_URI)

// 🚨 Ajustá estos dos si querés otro mail/clave
const email = "admin@duoclub.ar";   // 👈 el mail que quieras
const plainPassword = "Duoclub123"; // 👈 la clave que quieras

async function main() {
  try {
    if (!process.env.MONGO_URI) {
      console.error("❌ MONGO_URI no definido en .env");
      process.exit(1);
    }

    console.log("Conectando a MongoDB...");
    await mongoose.connect(process.env.MONGO_URI);

    console.log(`Buscando usuario con email: ${email}`);
    const user = await User.findOne({ email: email.toLowerCase() });

    if (!user) {
      console.error("❌ No se encontró ningún usuario con ese email.");
      process.exit(1);
    }

    console.log(`Usuario encontrado: ${user.name || "(sin nombre)"} (${user.email})`);

    const hash = await bcrypt.hash(plainPassword, 10);

    user.password = hash;
    user.mustChangePassword = false;   // o true si querés obligar a cambiarla al entrar
    user.role = "admin";               // aseguramos que sea admin

    await user.save();

    console.log("✅ Contraseña actualizada correctamente.");
    console.log("=======================================");
    console.log(` Email: ${email}`);
    console.log(` Nueva contraseña: ${plainPassword}`);
    console.log("=======================================");

    await mongoose.disconnect();
    process.exit(0);
  } catch (err) {
    console.error("❌ Error al resetear contraseña:", err);
    process.exit(1);
  }
}

main();
